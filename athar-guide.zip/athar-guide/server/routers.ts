import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { assertAIEnvironment, validateServerEnvironment } from "./env-validation";
import { parseAnalysisResponse } from "./analysis-validation";
import { TRPCError } from "@trpc/server";
import { KNOWLEDGE_ENTRIES, KNOWLEDGE_SOURCES } from "../shared/knowledge";
import { z } from "zod";

validateServerEnvironment();

const knowledgeContext = KNOWLEDGE_ENTRIES.map((entry) => {
  const sourceNames = entry.sourceIds.map((id) => KNOWLEDGE_SOURCES.find((source) => source.id === id)?.title).filter(Boolean).join("، ");
  return `${entry.name}: ${entry.description} التفسيرات المحتملة: ${entry.archaeologicalInterpretations.join(" | ")} المصدر: ${sourceNames || "لا يوجد مصدر مباشر"}`;
}).join("\\n");

const safetySystemPrompt = `أنت مساعد تحليل بصري أثري للشرق الأوسط (Middle Eastern Archaeological Visual Analysis Assistant)، ولست أداة لكشف الكنوز.
اتبع المراحل بالترتيب: Observe ثم Measure ثم Classify ثم Compare ثم Retrieve sources ثم Interpret ثم State uncertainty.
افصل دائمًا بين: ملاحظ بصريًا، مقاس، مستنتج، موثق، وفرضية. لا تدّعِ اليقين في التاريخ أو العمر أو الوظيفة، ولا تخترع مصادر أو معلومات أو قياسات.
ميّز لكل عنصر بين طبيعي محتمل وبشري الصنع محتمل وغير حاسم، واشرح الأدلة المؤيدة والمعارضة. إذا لم يوجد مقياس حقيقي، اكتب أن القياس غير متاح ولا تقدّر أبعادًا من الصورة.
لا تقدّم إحداثيات أو اتجاهات أو أعماق أو مسافات أو أماكن حفر أو تعليمات حفر أو تنقيب أو فتح قبور أو تجاوز حماية المواقع الأثرية. لا تدّعِ وجود ذهب أو معدن أو كنز أو دفين. إذا طلب المستخدم ذلك، ارفض بلطف ووجّه الحديث إلى التوثيق غير المتلف والجهات الأثرية الرسمية.
افصل التفسيرات الأثرية عن التفسيرات الشعبية، ووسم الشعبية بأنها غير مثبتة أثريًا. إذا لم يكن المصدر متحققًا، لا تعرضه كمصدر موثوق. إذا كانت الصورة غير واضحة، صرّح بذلك. اكتب بالعربية الواضحة وبأسلوب احتمالي غير مضلل.
قاعدة المعرفة المرجعية المحلية (استخدمها للمقارنة فقط ولا تنسب إليها ما لا تدعمه):
${knowledgeContext}`;

const imageDataUrl = z.string().regex(/^data:image\/(jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/).max(4_500_000);
const safeNote = z.string().trim().max(500).optional();
const imageDataUrls = z.array(imageDataUrl).min(1).max(6).refine((urls) => urls.reduce((total, url) => total + url.length, 0) <= 12_000_000, "حجم الصور الإجمالي كبير").optional();
const imageRoles = z.array(z.string().trim().min(2).max(40)).max(6).optional();
const resultFormat = {
  type: "json_object" as const,
};

const resultInstructions = `أعد JSON فقط بهذه المفاتيح دون أي مفاتيح إضافية:
{
  "title": "عنوان وصفي محايد",
  "category": "هندسي أو كتابي أو زخرفي أو حيواني أو نباتي أو معماري أو غير واضح أو غير ذلك",
  "summary": "وصف بصري محايد لما نراه",
  "observations": ["ملاحظة بصرية 1"],
  "interpretations": [{"label": "احتمال ثقافي أول", "explanation": "سبب احتمالي واضح"}],
  "why": "الأدلة البصرية التي دعمت الاحتمالات",
  "confidence": "منخفضة أو متوسطة أو مرتفعة",
  "limitations": "تنبيه يوضح أن الثقة لا تثبت الأصل أو العمر أو الوظيفة",
  "whatCannotInfer": ["لا يمكن استنتاج ..."],
  "documentationSteps": ["صوّر من زاوية أخرى"],
  "nextSafeStep": "خطوة توثيق آمنة واحدة",
  "imageQuality": "تقييم جودة الصورة وحدودها",
  "elements": [{"name": "عنصر محتمل", "classification": "غير حاسم", "description": "وصف بصري دون جزم"}],
  "measurements": [{"label": "قطر أو طول", "value": "غير متاح دون مقياس", "basis": "غير متاح"}],
  "relationships": ["وصف العلاقة المكانية داخل الصورة فقط"],
  "evidence": [{"level": "ملاحظ بصريًا", "statement": "ما يظهر بوضوح", "basis": "الصورة"}],
  "sources": []
}
يجب أن يحتوي interpretations على احتمالين على الأقل عندما تسمح الصورة بذلك، وألا تعرض نسبًا مئوية توحي بقياس علمي حقيقي. لا تضع مصدرًا أو رابطًا إلا إذا كان متحققًا؛ وإلا اجعل sources فارغة.`;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  analysis: router({
    analyze: publicProcedure
      .input(z.object({ imageDataUrl, imageDataUrls, imageRoles, note: safeNote }))
      .mutation(async ({ input }) => {
        assertAIEnvironment();
        try {
        const response = await invokeLLM({
          model: "gemini-3-flash-preview",
          messages: [
            { role: "system", content: `${safetySystemPrompt}\n${resultInstructions}` },
            {
              role: "user",
              content: [
                { type: "text", text: `حلّل الصور بصريًا وثقافيًا فقط. عدد الصور: ${(input.imageDataUrls || [input.imageDataUrl]).length}. أدوار الصور: ${input.imageRoles?.join("، ") || "واجهة عامة"}. ملاحظة المستخدم الاختيارية: ${input.note || "لا توجد"}` },
                ...(input.imageDataUrls || [input.imageDataUrl]).map((url) => ({ type: "image_url" as const, image_url: { url, detail: "auto" as const } })),
              ],
            },
          ],
          response_format: resultFormat,
          maxTokens: 1600,
        });

        return parseAnalysisResponse(response.choices[0]?.message?.content);
        } catch (error) {
          console.error("[analysis] request failed", error instanceof Error ? error.message : "unknown error");
          throw new TRPCError({ code: "BAD_GATEWAY", message: "تعذر إكمال التحليل الآمن. تحقق من الصورة والاتصال ثم حاول مرة أخرى." });
        }
      }),
    ask: publicProcedure
      .input(z.object({ question: z.string().trim().min(2).max(1000), context: z.string().max(2500).optional() }))
      .mutation(async ({ input }) => {
        assertAIEnvironment();
        const response = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            { role: "system", content: safetySystemPrompt },
            { role: "user", content: `السياق السابق: ${input.context || "لا يوجد"}\n\nسؤال المستخدم: ${input.question}` },
          ],
          maxTokens: 900,
          reasoning: { effort: "minimal" },
        });
        const text = response.choices[0]?.message?.content;
        return { answer: typeof text === "string" ? text : "تعذر توليد إجابة الآن." };
      }),
  }),
});

export type AppRouter = typeof appRouter;
