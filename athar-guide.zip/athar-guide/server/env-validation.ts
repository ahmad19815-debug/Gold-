import { z } from "zod";

const environmentSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  JWT_SECRET: z.string().min(1).optional(),
  DATABASE_URL: z.string().min(1).optional(),
  OAUTH_SERVER_URL: z.string().url().optional(),
  BUILT_IN_FORGE_API_URL: z.string().url().optional(),
  BUILT_IN_FORGE_API_KEY: z.string().min(1).optional(),
});

export function validateServerEnvironment() {
  const parsed = environmentSchema.safeParse(process.env);
  if (!parsed.success) {
    throw new Error("إعدادات بيئة الخادم غير صالحة. راجع متغيرات البيئة المطلوبة.");
  }

  const requiredInProduction = ["JWT_SECRET", "OAUTH_SERVER_URL", "BUILT_IN_FORGE_API_URL", "BUILT_IN_FORGE_API_KEY"] as const;
  if (parsed.data.NODE_ENV === "production") {
    const missing = requiredInProduction.filter((key) => !parsed.data[key]);
    if (missing.length > 0) {
      throw new Error(`متغيرات بيئة الخادم المطلوبة مفقودة: ${missing.join(", ")}`);
    }
  }

  return parsed.data;
}

export function assertAIEnvironment() {
  const forgeUrl = process.env.BUILT_IN_FORGE_API_URL;
  const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;
  if (!forgeUrl || !forgeKey) {
    throw new Error("خدمة الذكاء الاصطناعي غير مهيأة حاليًا.");
  }
}
