import { analysisResultSchema, type AnalysisResult } from "../shared/analysis";

export function parseAnalysisResponse(raw: unknown): AnalysisResult {
  if (typeof raw !== "string") {
    throw new Error("لم تصل نتيجة تحليل قابلة للعرض.");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error("أعاد المساعد نتيجة غير صالحة. أعد المحاولة بصورة أوضح.");
  }

  const validated = analysisResultSchema.safeParse(parsed);
  if (!validated.success) {
    throw new Error("تعذر التحقق من نتيجة التحليل. أعد المحاولة بصورة أوضح.");
  }

  return validated.data;
}
