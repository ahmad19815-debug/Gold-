import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";

const ONBOARDING_KEY = "athar-onboarding-seen";

export default function OnboardingScreen() {
  const continueToApp = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    router.replace("/(tabs)");
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-6">
      <View style={styles.content}>
        <View style={styles.mark}><Text style={styles.glyph}>✦</Text></View>
        <Text style={styles.kicker}>مرحبًا بك في</Text>
        <Text style={styles.title}>دليل الأثر</Text>
        <Text style={styles.subtitle}>افهم ما تراه قبل أن تفسّره.</Text>
        <Text style={styles.body}>حلّل الرموز والنقوش بصريًا وثقافيًا بمساعدة الذكاء الاصطناعي، ووثّق ما تراه دون إتلاف المكان أو القطعة.</Text>

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>قبل أن تبدأ</Text>
          <Text style={styles.noticeText}>الصورة لا تثبت العمر أو الأصل أو الوظيفة، ولا تكشف ذهبًا أو دفائن أو معادن. لا يقدّم التطبيق عمقًا أو اتجاهًا أو تعليمات حفر.</Text>
        </View>

        <Pressable accessibilityRole="button" accessibilityLabel="البدء باستخدام دليل الأثر" onPress={() => void continueToApp()} style={({ pressed }) => [styles.button, pressed && styles.pressed]}>
          <Text style={styles.buttonText}>ابدأ بأمان</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { flex: 1, justifyContent: "center", gap: 12 },
  mark: { width: 68, height: 68, borderRadius: 22, backgroundColor: "#B66A3C", justifyContent: "center", alignItems: "center", alignSelf: "flex-end", marginBottom: 16 },
  glyph: { color: "#FFFDF8", fontSize: 34 },
  kicker: { color: "#B66A3C", fontSize: 15, fontWeight: "800", textAlign: "right" },
  title: { color: "#202522", fontSize: 38, lineHeight: 46, fontWeight: "900", textAlign: "right" },
  subtitle: { color: "#5D6B4B", fontSize: 19, fontWeight: "800", textAlign: "right" },
  body: { color: "#5D6655", fontSize: 15, lineHeight: 24, textAlign: "right", marginTop: 6 },
  notice: { backgroundColor: "#FFF3D9", borderWidth: 1, borderColor: "#E9D7AB", borderRadius: 18, padding: 16, marginTop: 8, gap: 5 },
  noticeTitle: { color: "#805B19", fontSize: 15, fontWeight: "800", textAlign: "right" },
  noticeText: { color: "#775E31", fontSize: 13, lineHeight: 21, textAlign: "right" },
  button: { minHeight: 56, borderRadius: 17, backgroundColor: "#5D6B4B", alignItems: "center", justifyContent: "center", marginTop: 10 },
  buttonText: { color: "#FFFDF8", fontSize: 16, fontWeight: "800" },
  pressed: { opacity: 0.8, transform: [{ scale: 0.98 }] },
});
