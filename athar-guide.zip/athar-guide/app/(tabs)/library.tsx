import { useMemo, useState } from "react";
import { FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { KNOWLEDGE_ENTRIES, KNOWLEDGE_GROUPS, KNOWLEDGE_REGIONS, KNOWLEDGE_SOURCES } from "@/shared/knowledge";
import { matchesSearch } from "@/shared/search";

export default function LibraryScreen() {
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("الكل");
  const [region, setRegion] = useState("كل المناطق");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const data = useMemo(() => {
      return KNOWLEDGE_ENTRIES.filter((entry) => {
      const searchable = [entry.name, entry.group, ...entry.englishNames, ...entry.regions, ...entry.periods];
      return matchesSearch(query, searchable) && (group === "الكل" || entry.group === group) && (region === "كل المناطق" || entry.regions.includes(region));
    });
  }, [group, query, region]);
  const selected = selectedId ? KNOWLEDGE_ENTRIES.find((entry) => entry.id === selectedId) : null;
  const selectedSources = selected ? selected.sourceIds.map((id) => KNOWLEDGE_SOURCES.find((source) => source.id === id)).filter(Boolean) : [];

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <View style={styles.header}><Text style={styles.kicker}>معرفة قبل التفسير</Text><Text style={styles.title}>قاعدة المعرفة</Text><Text style={styles.subtitle}>أمثلة عربية وشرق أوسطية بصياغة احتمالية ومراجع قابلة للتحقق.</Text></View>
      <TextInput value={query} onChangeText={setQuery} placeholder="ابحث بالعربية أو الإنجليزية" placeholderTextColor="#978F84" style={styles.search} accessibilityLabel="البحث في قاعدة المعرفة" />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips} style={styles.chipRow}>
        {KNOWLEDGE_GROUPS.map((item) => <Pressable key={item} accessibilityRole="button" accessibilityLabel={`فلترة الفئة ${item}`} onPress={() => setGroup(item)} style={[styles.chip, group === item && styles.activeChip]}><Text style={[styles.chipText, group === item && styles.activeChipText]}>{item}</Text></Pressable>)}
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips} style={styles.chipRow}>
        {KNOWLEDGE_REGIONS.slice(0, 9).map((item) => <Pressable key={item} accessibilityRole="button" accessibilityLabel={`فلترة المنطقة ${item}`} onPress={() => setRegion(item)} style={[styles.chip, region === item && styles.activeRegionChip]}><Text style={[styles.chipText, region === item && styles.activeRegionText]}>{item}</Text></Pressable>)}
      </ScrollView>
      {selected && (
        <View style={styles.detailCard}>
          <View style={styles.detailHeading}><Pressable accessibilityRole="button" accessibilityLabel="إغلاق تفاصيل العنصر" onPress={() => setSelectedId(null)} style={styles.closeButton}><Text style={styles.closeText}>إغلاق</Text></Pressable><Text style={styles.detailTitle}>{selected.name}</Text></View>
          <Text style={styles.group}>{selected.group} · {selected.regions.slice(0, 2).join("، ")}</Text>
          <Text style={styles.detailText}>{selected.description}</Text>
          <Text style={styles.sectionTitle}>تفسيرات أثرية محتملة</Text>
          {selected.archaeologicalInterpretations.map((text) => <Text key={text} style={styles.detailText}>• {text}</Text>)}
          <Text style={styles.sectionTitle}>التفسيرات الشعبية المتداولة</Text>
          {selected.popularInterpretations.map((text) => <Text key={text} style={styles.popularText}>{text}</Text>)}
          <Text style={styles.sectionTitle}>المصدر</Text>
          {selectedSources.map((source) => source && <Text key={source.id} style={styles.sourceText}>{source.authorOrInstitution}، {source.title} ({source.year ?? "دون سنة"}) · {source.verified ? "متحقق" : "غير متحقق"}</Text>)}
        </View>
      )}
      <FlatList data={data} keyExtractor={(item) => item.id} contentContainerStyle={styles.list} renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={`عرض تفاصيل ${item.name}`} onPress={() => setSelectedId(item.id)} style={({ pressed }) => [styles.card, pressed && styles.pressed]}><View style={styles.symbolCircle}><Text style={styles.symbolGlyph}>{item.name.slice(0, 1)}</Text></View><View style={styles.cardBody}><Text style={styles.group}>{item.group}</Text><Text style={styles.cardTitle}>{item.name}</Text><Text style={styles.description}>{item.description}</Text><Text style={styles.tapHint}>اضغط لعرض الأدلة والمصدر</Text></View></Pressable>} ListEmptyComponent={<Text style={styles.empty}>لا توجد نتائج بهذه الفلاتر.</Text>} />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: 20, paddingBottom: 8 }, kicker: { color: "#B66A3C", fontSize: 14, fontWeight: "800", textAlign: "right" }, title: { color: "#202522", fontSize: 30, lineHeight: 38, fontWeight: "800", textAlign: "right", marginTop: 3 }, subtitle: { color: "#817A70", fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 5 }, search: { backgroundColor: "#FFFDF8", borderColor: "#E3D7C6", borderWidth: 1, borderRadius: 15, padding: 14, color: "#202522", textAlign: "right", fontSize: 14 }, chipRow: { flexGrow: 0, marginTop: 9 }, chips: { flexDirection: "row-reverse", gap: 7, paddingVertical: 2 }, chip: { borderWidth: 1, borderColor: "#E3D7C6", backgroundColor: "#FFFDF8", paddingHorizontal: 11, paddingVertical: 8, borderRadius: 20 }, activeChip: { backgroundColor: "#5D6B4B", borderColor: "#5D6B4B" }, activeRegionChip: { backgroundColor: "#F4E5D9", borderColor: "#B66A3C" }, chipText: { color: "#817A70", fontSize: 11, fontWeight: "700" }, activeChipText: { color: "#FFFDF8" }, activeRegionText: { color: "#8A4526" }, detailCard: { backgroundColor: "#EEF0E8", borderColor: "#D8DDCE", borderWidth: 1, borderRadius: 18, padding: 15, gap: 7, marginTop: 10 }, detailHeading: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }, detailTitle: { color: "#202522", fontSize: 20, fontWeight: "800", textAlign: "right" }, closeButton: { paddingVertical: 5, paddingHorizontal: 8 }, closeText: { color: "#8A4526", fontSize: 12, fontWeight: "800" }, detailText: { color: "#46533A", fontSize: 13, lineHeight: 21, textAlign: "right" }, sectionTitle: { color: "#46533A", fontSize: 13, fontWeight: "800", textAlign: "right", marginTop: 4 }, popularText: { color: "#8A4526", fontSize: 12, lineHeight: 19, textAlign: "right" }, sourceText: { color: "#5D6655", fontSize: 11, lineHeight: 17, textAlign: "right" }, list: { paddingTop: 12, paddingBottom: 30, gap: 10 }, card: { flexDirection: "row-reverse", gap: 13, alignItems: "flex-start", backgroundColor: "#FFFDF8", borderWidth: 1, borderColor: "#E3D7C6", borderRadius: 18, padding: 14 }, symbolCircle: { width: 48, height: 48, borderRadius: 16, backgroundColor: "#F4E5D9", alignItems: "center", justifyContent: "center" }, symbolGlyph: { color: "#8A4526", fontWeight: "800", fontSize: 22 }, cardBody: { flex: 1 }, group: { color: "#B66A3C", fontSize: 11, fontWeight: "800", textAlign: "right" }, cardTitle: { color: "#202522", fontSize: 17, fontWeight: "800", textAlign: "right", marginTop: 2 }, description: { color: "#5D6655", fontSize: 13, lineHeight: 19, textAlign: "right", marginTop: 4 }, tapHint: { color: "#B66A3C", fontSize: 11, fontWeight: "700", textAlign: "right", marginTop: 8 }, pressed: { opacity: 0.75 }, empty: { color: "#817A70", textAlign: "center", paddingTop: 30 },
});
