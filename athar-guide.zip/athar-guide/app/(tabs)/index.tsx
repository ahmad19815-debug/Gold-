import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";
import { useEffect, useState } from "react";
import { ActivityIndicator, AppState, GestureResponderEvent, Image, Platform, Pressable, ScrollView, Share, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import { showUserMessage } from "@/lib/user-feedback";
import type { AnalysisResult } from "@/shared/analysis";
import { KNOWLEDGE_ENTRIES, KNOWLEDGE_SOURCES } from "@/shared/knowledge";
import { calibratedMeasurement, distanceBetweenPoints, type MeasurementPoint } from "@/shared/measurement";
import { isAcceptableImageAsset } from "@/shared/image-policy";
import { toImageDataUrl } from "@/shared/image-data";

const HISTORY_KEY = "athar-analysis-history";
type PickerMode = "camera" | "library" | null;
type ImageRole = "واجهة عامة" | "تفاصيل" | "سياق" | "مقياس";
const IMAGE_ROLES: ImageRole[] = ["واجهة عامة", "تفاصيل", "سياق", "مقياس"];
type MeasurePoint = MeasurementPoint;
const normalizedWords = (value: string) => value.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").split(/\s+/).filter((word) => word.length > 2);
const compareWithKnowledge = (analysis: AnalysisResult) => {
  const observedWords = new Set(normalizedWords([analysis.title, analysis.category, ...analysis.observations, ...(analysis.elements?.map((item) => `${item.name} ${item.classification}`) || [])].join(" ")));
  return KNOWLEDGE_ENTRIES.map((entry) => {
    const entryWords = new Set(normalizedWords([entry.name, entry.group, ...entry.englishNames].join(" ")));
    const overlap = [...observedWords].filter((word) => entryWords.has(word)).length;
    const sourceCount = entry.sourceIds.filter((id) => KNOWLEDGE_SOURCES.some((source) => source.id === id && source.verified)).length;
    return { entry, score: Math.min(92, overlap * 18 + (sourceCount > 0 ? 8 : 0)) };
  }).filter((candidate) => candidate.score > 8).sort((a, b) => b.score - a.score).slice(0, 3);
};

export default function HomeScreen() {
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [imageUris, setImageUris] = useState<string[]>([]);
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [imageDataUrls, setImageDataUrls] = useState<string[]>([]);
  const [imageRoles, setImageRoles] = useState<ImageRole[]>([]);
  const [measureMode, setMeasureMode] = useState<"reference" | "object" | null>(null);
  const [measurePoints, setMeasurePoints] = useState<MeasurePoint[]>([]);
  const [calibrationPixels, setCalibrationPixels] = useState<number | null>(null);
  const [measuredCentimeters, setMeasuredCentimeters] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [referenceCm, setReferenceCm] = useState("");
  const [referencePixels, setReferencePixels] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [pickerMode, setPickerMode] = useState<PickerMode>(null);
  const [analysisStage, setAnalysisStage] = useState("");

  const applyPickerResult = async (response: ImagePicker.ImagePickerResult) => {
    if (response.canceled || !response.assets?.length) return;

    const validAssets = response.assets.filter(isAcceptableImageAsset);
    if (!validAssets.length) {
      showUserMessage("الصورة غير مناسبة", "اختر صورة JPG أو PNG أو WebP واضحة وأقل من 8 ميغابايت.");
      return;
    }
    const preparedAssets = await Promise.all(validAssets.map(async (asset) => {
      try {
        const targetWidth = Math.min(asset.width || 1600, 1400);
        const compressed = await ImageManipulator.manipulateAsync(asset.uri, [{ resize: { width: targetWidth } }], { compress: 0.62, format: ImageManipulator.SaveFormat.JPEG, base64: true });
        return { ...asset, uri: compressed.uri, base64: compressed.base64 ?? asset.base64, mimeType: "image/jpeg", width: compressed.width, height: compressed.height };
      } catch {
        return asset;
      }
    }));
    const uris = preparedAssets.map((asset) => asset.uri);
    const dataUrls = (await Promise.all(preparedAssets.map((asset) => toImageDataUrl(asset)))).filter((value): value is string => Boolean(value));
    if (dataUrls.length !== preparedAssets.length) {
      showUserMessage("الصورة غير قابلة للإرسال", "تعذر قراءة بيانات إحدى الصور. اختر الصور من جديد أو استخدم صورة JPG أصغر.");
      return;
    }
    if (dataUrls.some((value) => value.length > 4_200_000)) {
      showUserMessage("الصورة كبيرة جدًا", "اختر صورة بدقة أقل من 8 ميغابايت؛ سيتم ضغطها قبل التحليل.");
      return;
    }
    setImageUri(uris[0]);
    setImageUris(uris);
    setImageDataUrl(dataUrls[0] || null);
    setImageDataUrls(dataUrls);
    setImageRoles(uris.map((_, index) => index === 0 ? "واجهة عامة" : "تفاصيل"));
    setMeasureMode(null);
    setMeasurePoints([]);
    setCalibrationPixels(null);
    setMeasuredCentimeters(null);
    setResult(null);
    if (preparedAssets.length > 1) showUserMessage("تمت إضافة الصور", `سيُدمج ${preparedAssets.length} صور في تحليل واحد.`);
    if (dataUrls.length !== preparedAssets.length) showUserMessage("الصور جاهزة", "إحدى الصور لا تحتوي على بيانات قابلة للإرسال؛ أعد اختيارها مع اتصال نشط للتحليل الذكي.");
  };

  useEffect(() => {
    const restorePendingResult = async () => {
      try {
        const pending = await ImagePicker.getPendingResultAsync();
        if (pending && "assets" in pending) void applyPickerResult(pending);
      } catch {
        // Some Android versions do not expose a pending picker result; normal selection still works.
      }
    };

    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active") void restorePendingResult();
    });

    return () => subscription.remove();
  }, []);

  const analyzeMutation = trpc.analysis.analyze.useMutation({
    onSuccess: async (data) => {
      setResult(data);
      try {
        const previous = await AsyncStorage.getItem(HISTORY_KEY);
        const history = previous ? JSON.parse(previous) : [];
        await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify([
          { id: Date.now().toString(), createdAt: new Date().toISOString(), imageUri, result: data },
          ...history,
        ].slice(0, 20)));
      } catch {
        showUserMessage("تم التحليل", "ظهرت النتيجة، لكن تعذر حفظها محليًا في السجل.");
      }
    },
    onError: (error) => showUserMessage("تعذر التحليل", error.message || "تحقق من الاتصال ثم حاول مرة أخرى."),
  });

  const selectImage = async (fromCamera: boolean) => {
    setPickerMode(fromCamera ? "camera" : "library");
    try {
      if (fromCamera) {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) {
          showUserMessage("نحتاج إذن الكاميرا", "اسمح بالوصول إلى الكاميرا من إعدادات الهاتف لالتقاط صورة للرمز.");
          return;
        }
      }

      const response = fromCamera
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 0.7,
            base64: true,
            exif: false,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: false,
            allowsMultipleSelection: true,
            selectionLimit: 6,
            quality: 0.7,
            base64: true,
            exif: false,
          });

      await applyPickerResult(response);
    } catch (error) {
      const message = error instanceof Error ? error.message : "تعذر فتح أداة اختيار الصورة.";
      showUserMessage("تعذر فتح الصور", message);
    } finally {
      setPickerMode(null);
    }
  };

  useEffect(() => {
    if (!analyzeMutation.isPending) {
      setAnalysisStage("");
      return;
    }
    const stages = ["جارٍ فحص الصورة…", "تحليل السمات البصرية…", "مقارنة الأنماط…", "إعداد النتيجة…"];
    let index = 0;
    setAnalysisStage(stages[index]);
    const timer = setInterval(() => {
      index = Math.min(index + 1, stages.length - 1);
      setAnalysisStage(stages[index]);
    }, 1400);
    return () => clearInterval(timer);
  }, [analyzeMutation.isPending]);

  const handleMeasureTap = (event: GestureResponderEvent) => {
    if (!measureMode) return;
    const nextPoint = { x: event.nativeEvent.locationX, y: event.nativeEvent.locationY };
    const nextPoints = [...measurePoints, nextPoint];
    if (nextPoints.length < 2) {
      setMeasurePoints(nextPoints);
      return;
    }
    const pixels = distanceBetweenPoints(nextPoints[0], nextPoints[1]);
    if (measureMode === "reference") {
      const referenceLength = Number(referenceCm.replace(",", "."));
      if (!Number.isFinite(referenceLength) || referenceLength <= 0) {
        showUserMessage("أدخل طول المرجع", "اكتب طول المسطرة أو المرجع الحقيقي بالسنتيمتر قبل تحديد النقطتين.");
        setMeasurePoints([]);
        return;
      }
      setCalibrationPixels(pixels);
      setReferencePixels(String(Math.round(pixels)));
      setMeasureMode("object");
      setMeasurePoints([]);
      showUserMessage("تمت المعايرة", "الآن انقر نقطتين على الجزء المطلوب قياسه.");
      return;
    }
    const referenceLength = Number(referenceCm.replace(",", "."));
    if (!calibrationPixels || !Number.isFinite(referenceLength) || referenceLength <= 0) {
      showUserMessage("المعايرة مطلوبة", "حدّد نقطتي المرجع الحقيقي أولًا قبل قياس أي جزء.");
      setMeasurePoints([]);
      return;
    }
    setMeasuredCentimeters(calibratedMeasurement(pixels, calibrationPixels, referenceLength));
    setMeasurePoints([]);
    showUserMessage("اكتمل القياس", "النتيجة تقديرية للصورة المعايرة وليست قياسًا ميدانيًا.");
  };

  const comparisonCandidates = result ? compareWithKnowledge(result) : [];

  const analyze = () => {
    if (!imageDataUrl) {
      showUserMessage("الصورة غير جاهزة", "اختر صورة جديدة من الكاميرا أو المعرض، ثم حاول مرة أخرى.");
      return;
    }
    const scaleNote = measuredCentimeters ? `قياس تقريبي معاير: ${measuredCentimeters.toFixed(1)} سم.` : referenceCm.trim() && referencePixels.trim() ? `مرجع قياس: ${referenceCm.trim()} سم يساوي ${referencePixels.trim()} بكسل بعد تحديد نقطتين يدويًا.` : "لا يوجد مرجع قياس معاير؛ لا تستنتج أبعادًا حقيقية.";
    const rolesNote = imageRoles.length > 1 ? `أدوار الصور بالترتيب: ${imageRoles.map((role, index) => `${index + 1}=${role}`).join("، ")}.` : "الصورة الوحيدة هي الواجهة العامة.";
    analyzeMutation.mutate({ imageDataUrl, imageDataUrls: imageDataUrls.length > 1 ? imageDataUrls : undefined, imageRoles: imageRoles.length > 1 ? imageRoles : undefined, note: [note.trim(), scaleNote, rolesNote].filter(Boolean).join(" ") || undefined });
  };

  const shareResult = async () => {
    if (!result) return;
    const message = `${result.title}\n${result.summary}\n\nتنبيه: هذه قراءة ثقافية احتمالية وليست إثباتًا أثريًا أو كشفًا للذهب أو الدفائن.`;
    try {
      if (Platform.OS === "web" && typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({ title: "نتيجة من دليل الأثر", text: message });
      } else if (Platform.OS !== "web") {
        await Share.share({ message });
      } else {
        showUserMessage("المشاركة غير متاحة", "استخدم أدوات المتصفح لنسخ النتيجة يدويًا.");
      }
    } catch {
      showUserMessage("تعذر المشاركة", "يمكنك نسخ ملخص النتيجة يدويًا.");
    }
  };

  const actionDisabled = pickerMode !== null || analyzeMutation.isPending;

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>دليل الأثر</Text>
            <Text style={styles.title}>افهم الرمز قبل أن تفسّره</Text>
          </View>
          <View style={styles.logoMark}><Text style={styles.logoGlyph}>✦</Text></View>
        </View>

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>تحليل ثقافي، لا كشف كنوز</Text>
          <Text style={styles.noticeText}>المساعد يقرأ الملامح الظاهرة ويقارنها بسياقات تراثية. الصورة وحدها لا تثبت وجود ذهب أو دفائن ولا تحدد عمقًا أو اتجاهًا.</Text>
        </View>

        <Text style={styles.sectionTitle}>ابدأ بصورة واضحة</Text>
        {imageUri ? (
          <View style={styles.previewCard}>
            <View onStartShouldSetResponder={() => Boolean(measureMode)} onResponderRelease={handleMeasureTap}><Image source={{ uri: imageUri }} style={styles.preview} /></View>
            {imageUris.length > 1 && <>
              <Text style={styles.multiImageLabel}>تم اختيار {imageUris.length} صور للتحليل المشترك</Text>
              <View style={styles.rolesBox}><Text style={styles.rolesTitle}>حدّد دور كل صورة</Text>{imageUris.map((uri, index) => <View key={`${uri}-${index}`} style={styles.roleRow}><Image source={{ uri }} style={styles.roleThumb} /><View style={styles.roleOptions}><Text style={styles.roleLabel}>الصورة {index + 1}</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.roleChips}>{IMAGE_ROLES.map((role) => <Pressable key={role} accessibilityRole="button" accessibilityLabel={`تعيين الصورة ${index + 1} كـ ${role}`} onPress={() => setImageRoles((current) => current.map((value, roleIndex) => roleIndex === index ? role : value))} style={[styles.roleChip, imageRoles[index] === role && styles.activeRoleChip]}><Text style={[styles.roleChipText, imageRoles[index] === role && styles.activeRoleChipText]}>{role}</Text></Pressable>)}</ScrollView></View></View>)}</View>
            </>}
            <Pressable testID="change-image" disabled={actionDisabled} onPress={() => void selectImage(false)} style={({ pressed }) => [styles.changeButton, pressed && styles.pressed, actionDisabled && styles.disabled]}>
              <Text style={styles.changeText}>{pickerMode === "library" ? "جارٍ فتح المعرض…" : "تغيير الصورة"}</Text>
            </Pressable>
          </View>
        ) : (
          <View style={styles.emptyPreview}>
            <Text style={styles.cameraIcon}>⌾</Text>
            <Text style={styles.emptyTitle}>صوّر الرمز من دون إتلافه</Text>
            <Text style={styles.emptyText}>قرّب الصورة، اجعل الإضاءة متوازنة، ولا تحرّك أي حجر أو قطعة.</Text>
          </View>
        )}

        <View style={styles.actionsRow}>
          <Pressable testID="take-photo" disabled={actionDisabled} onPress={() => void selectImage(true)} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed, actionDisabled && styles.disabled]}>
            {pickerMode === "camera" ? <ActivityIndicator color="#FFFDF8" /> : <Text style={styles.primaryButtonText}>التقاط صورة</Text>}
          </Pressable>
          <Pressable testID="pick-from-library" disabled={actionDisabled} onPress={() => void selectImage(false)} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed, actionDisabled && styles.disabled]}>
            {pickerMode === "library" ? <ActivityIndicator color="#6D4B35" /> : <Text style={styles.secondaryButtonText}>من المعرض</Text>}
          </Pressable>
        </View>

        <Text style={styles.privacyNote}>الخصوصية أولًا: لا نقرأ أو نعرض موقع الصورة الجغرافي تلقائيًا.</Text>
        <Text style={styles.label}>معايرة اختيارية للقياس</Text>
        <Text style={styles.helperText}>ضع مقياسًا حقيقيًا في الصورة وسجّل طول المرجع والمسافة بالبكسل بعد تحديد نقطتين. دون ذلك ستظهر القياسات «غير متاحة».</Text>
        <View style={styles.measureRow}><TextInput value={referenceCm} onChangeText={setReferenceCm} placeholder="الطول الحقيقي سم" placeholderTextColor="#978F84" keyboardType="decimal-pad" style={styles.measureInput} accessibilityLabel="الطول الحقيقي بالسنتيمتر" /><TextInput value={referencePixels} onChangeText={setReferencePixels} placeholder="المسافة بكسل" placeholderTextColor="#978F84" keyboardType="decimal-pad" style={styles.measureInput} accessibilityLabel="المسافة بالبكسل" /></View>
        <View style={styles.measureTools}><Text style={styles.measureStatus}>{measureMode === "reference" ? "انقر نقطتين على المرجع الظاهر داخل الصورة." : measureMode === "object" ? "انقر نقطتين على الجزء المطلوب قياسه." : "القياس لا يصبح متاحًا إلا بعد معايرة مرجع حقيقي."}</Text><View style={styles.measureActions}><Pressable accessibilityRole="button" onPress={() => { if (!referenceCm.trim()) { showUserMessage("أدخل طول المرجع", "اكتب طول المرجع الحقيقي بالسنتيمتر أولًا."); return; } setMeasurePoints([]); setMeasureMode("reference"); }} style={[styles.measureButton, measureMode === "reference" && styles.activeMeasureButton]}><Text style={styles.measureButtonText}>معايرة بالنقر</Text></Pressable>{calibrationPixels ? <Pressable accessibilityRole="button" onPress={() => { setMeasurePoints([]); setMeasureMode("object"); }} style={[styles.measureButton, measureMode === "object" && styles.activeMeasureButton]}><Text style={styles.measureButtonText}>قياس بالنقر</Text></Pressable> : null}</View>{measurePoints.length === 1 ? <Text style={styles.measureStatus}>تم تحديد النقطة الأولى؛ حدّد النقطة الثانية.</Text> : null}{measuredCentimeters ? <Text style={styles.measureResult}>القياس التقريبي: {measuredCentimeters.toFixed(1)} سم</Text> : null}</View>
        <Text style={styles.label}>ملاحظة اختيارية عن السياق</Text>
        <TextInput value={note} onChangeText={setNote} placeholder="مثال: نقش على صخرة قرب مبنى قديم" placeholderTextColor="#978F84" multiline style={styles.input} />

        <Pressable testID="analyze-image" disabled={!imageDataUrl || actionDisabled} onPress={analyze} style={({ pressed }) => [styles.analyzeButton, pressed && styles.pressed, (!imageDataUrl || actionDisabled) && styles.disabled]}>
          {analyzeMutation.isPending ? <View style={styles.loadingContent}><ActivityIndicator color="#FFFDF8" /><Text style={styles.analyzeText}>{analysisStage}</Text></View> : <Text style={styles.analyzeText}>حلّل ثقافيًا بالذكاء الاصطناعي</Text>}
        </Pressable>

        {result && (
          <View style={styles.resultCard}>
            <View style={styles.resultHeading}>
              <View style={styles.confidencePill}><Text style={styles.confidenceText}>ثقة {result.confidence}</Text></View>
              <Text style={styles.resultTitle}>{result.title}</Text>
            </View>
            <Text style={styles.category}>{result.category}</Text>
            <Text style={styles.resultSummary}>{result.summary}</Text>
            <Text style={styles.resultLabel}>ملاحظات من الصورة</Text>
            {result.observations.map((item, index) => <Text key={`${item}-${index}`} style={styles.bullet}>• {item}</Text>)}
            <Text style={styles.resultLabel}>التفسيرات المحتملة</Text>
            {result.interpretations.map((item, index) => <View key={`${item.label}-${index}`} style={styles.interpretation}><Text style={styles.interpretationTitle}>{item.label}</Text><Text style={styles.interpretationText}>{item.explanation}</Text></View>)}
            <Text style={styles.resultLabel}>لماذا؟</Text>
            <Text style={styles.resultSummary}>{result.why}</Text>
            {result.imageQuality && <View style={styles.evidenceBox}><Text style={styles.resultLabel}>جودة الصورة</Text><Text style={styles.resultSummary}>{result.imageQuality}</Text></View>}
            <View style={styles.evidenceBox}><Text style={styles.resultLabel}>مقارنة وصفية احتمالية</Text><Text style={styles.sourceText}>هذه المطابقة بالكلمات والسياق وليست تعرّفًا بصريًا قاطعًا، ولا تثبت الأصل أو الوظيفة.</Text>{comparisonCandidates.length ? comparisonCandidates.map(({ entry, score }) => <View key={entry.id} style={styles.comparisonRow}><Text style={styles.comparisonScore}>{score}% تشابه وصفي</Text><View style={styles.comparisonCopy}><Text style={styles.comparisonTitle}>{entry.name}</Text><Text style={styles.sourceText}>{entry.description}</Text><Text style={styles.sourceText}>المجموعة: {entry.group} · {entry.sourceIds.map((id) => KNOWLEDGE_SOURCES.find((source) => source.id === id)?.title).filter(Boolean).join("، ")}</Text></View></View>) : <Text style={styles.sourceText}>لا يوجد مثال قريب بما يكفي في القاعدة الحالية؛ أضف صورًا أو سياقًا أوضح.</Text>}<Text style={styles.sourceText}>النتيجة إرشادية فقط، ولا تقدم اتجاهًا أو مسافة أو عمقًا أو تعليمات حفر.</Text></View>
            {result.elements?.length ? <View style={styles.evidenceBox}><Text style={styles.resultLabel}>العناصر والتصنيف</Text>{result.elements.map((item, index) => <Text key={`${item.name}-${index}`} style={styles.bullet}>• {item.name}: {item.classification} — {item.description}</Text>)}</View> : null}
            {result.measurements?.length ? <View style={styles.evidenceBox}><Text style={styles.resultLabel}>القياسات</Text>{result.measurements.map((item, index) => <Text key={`${item.label}-${index}`} style={styles.bullet}>• {item.label}: {item.value} ({item.basis})</Text>)}</View> : null}
            {result.relationships?.length ? <View style={styles.evidenceBox}><Text style={styles.resultLabel}>العلاقات داخل الصورة</Text>{result.relationships.map((item, index) => <Text key={`${item}-${index}`} style={styles.bullet}>• {item}</Text>)}</View> : null}
            {result.evidence?.length ? <View style={styles.evidenceBox}><Text style={styles.resultLabel}>مستوى الدليل</Text>{result.evidence.map((item, index) => <Text key={`${item.statement}-${index}`} style={styles.bullet}>• {item.level}: {item.statement} — الأساس: {item.basis}</Text>)}</View> : null}
            {result.sources?.length ? <View style={styles.evidenceBox}><Text style={styles.resultLabel}>المصادر</Text>{result.sources.map((item, index) => <Text key={`${item.title}-${index}`} style={styles.sourceText}>• {item.title} — {item.verified ? "متحقق" : "غير متحقق"} ({item.reliability})</Text>)}</View> : null}
            <View style={styles.limitations}><Text style={styles.limitationsTitle}>ما الذي لا يمكن استنتاجه؟</Text>{result.whatCannotInfer.map((item, index) => <Text key={`${item}-${index}`} style={styles.limitationsText}>• {item}</Text>)}</View>
            <View style={styles.documentation}><Text style={styles.documentationTitle}>التوثيق المقترح</Text>{result.documentationSteps.map((item, index) => <Text key={`${item}-${index}`} style={styles.documentationText}>• {item}</Text>)}</View>
            <Text style={styles.safeStep}><Text style={styles.safeStepBold}>الخطوة الآمنة التالية: </Text>{result.nextSafeStep}</Text>
          <Text style={styles.savedLabel}>✓ حُفظت النتيجة محليًا على جهازك</Text>
          <View style={styles.resultActions}>
            <Pressable accessibilityRole="button" accessibilityLabel="مشاركة نتيجة التحليل" onPress={() => void shareResult()} style={({ pressed }) => [styles.resultAction, pressed && styles.pressed]}><Text style={styles.resultActionText}>مشاركة</Text></Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="إعادة تحليل الصورة" onPress={analyze} style={({ pressed }) => [styles.resultAction, pressed && styles.pressed]}><Text style={styles.resultActionText}>إعادة التحليل</Text></Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="الإبلاغ عن نتيجة غير مفيدة" onPress={() => showUserMessage("شكرًا لملاحظتك", "سنستخدمها لتحسين جودة التفسيرات التعليمية.")} style={({ pressed }) => [styles.resultAction, pressed && styles.pressed]}><Text style={styles.resultActionText}>غير مفيدة</Text></Pressable>
          </View>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 20, paddingBottom: 36, gap: 16 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { color: "#B66A3C", fontSize: 14, fontWeight: "700", textAlign: "right", letterSpacing: 0.5 },
  title: { color: "#202522", fontSize: 28, lineHeight: 36, fontWeight: "800", textAlign: "right", maxWidth: 290 },
  logoMark: { width: 52, height: 52, borderRadius: 17, backgroundColor: "#B66A3C", alignItems: "center", justifyContent: "center", shadowColor: "#8A4526", shadowOpacity: 0.2, shadowRadius: 10, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  logoGlyph: { color: "#FFFDF8", fontSize: 27 },
  notice: { backgroundColor: "#EEF0E8", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: "#D8DDCE" },
  noticeTitle: { color: "#46533A", fontWeight: "800", fontSize: 15, textAlign: "right", marginBottom: 5 },
  noticeText: { color: "#5D6655", fontSize: 13, lineHeight: 20, textAlign: "right" },
  sectionTitle: { color: "#202522", fontSize: 18, fontWeight: "800", textAlign: "right", marginTop: 6 },
  emptyPreview: { backgroundColor: "#FFFDF8", borderRadius: 22, borderWidth: 1, borderColor: "#E3D7C6", borderStyle: "dashed", padding: 26, alignItems: "center" },
  cameraIcon: { fontSize: 38, color: "#B66A3C", marginBottom: 8 },
  emptyTitle: { color: "#202522", fontSize: 16, fontWeight: "700", textAlign: "center" },
  emptyText: { color: "#817A70", fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 6, maxWidth: 280 },
  previewCard: { backgroundColor: "#FFFDF8", borderRadius: 22, overflow: "hidden", borderWidth: 1, borderColor: "#E3D7C6" },
  preview: { height: 220, width: "100%", backgroundColor: "#E8E0D4" },
  multiImageLabel: { color: "#6D4B35", fontSize: 12, fontWeight: "700", textAlign: "right", paddingHorizontal: 12, paddingTop: 10 },
  rolesBox: { padding: 12, gap: 9 },
  rolesTitle: { color: "#6D4B35", fontSize: 12, fontWeight: "800", textAlign: "right" },
  roleRow: { flexDirection: "row-reverse", alignItems: "center", gap: 9 },
  roleThumb: { width: 42, height: 42, borderRadius: 10, backgroundColor: "#E8E0D4" },
  roleOptions: { flex: 1, gap: 5 },
  roleLabel: { color: "#817A70", fontSize: 11, fontWeight: "700", textAlign: "right" },
  roleChips: { flexDirection: "row-reverse", gap: 5 },
  roleChip: { borderWidth: 1, borderColor: "#E3D7C6", borderRadius: 14, paddingHorizontal: 8, paddingVertical: 5, backgroundColor: "#FFFDF8" },
  activeRoleChip: { borderColor: "#B66A3C", backgroundColor: "#F4E5D9" },
  roleChipText: { color: "#817A70", fontSize: 10, fontWeight: "700" },
  activeRoleChipText: { color: "#8A4526" },
  changeButton: { padding: 12, alignItems: "center" },
  changeText: { color: "#B66A3C", fontWeight: "700" },
  actionsRow: { flexDirection: "row-reverse", gap: 10 },
  primaryButton: { flex: 1, backgroundColor: "#B66A3C", minHeight: 50, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  primaryButtonText: { color: "#FFFDF8", fontWeight: "800", fontSize: 15 },
  secondaryButton: { flex: 1, backgroundColor: "#FFFDF8", minHeight: 50, borderRadius: 15, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#E3D7C6" },
  secondaryButtonText: { color: "#6D4B35", fontWeight: "800", fontSize: 15 },
  privacyNote: { color: "#817A70", fontSize: 11, lineHeight: 17, textAlign: "right" },
  helperText: { color: "#817A70", fontSize: 11, lineHeight: 17, textAlign: "right" },
  measureRow: { flexDirection: "row-reverse", gap: 8 },
  measureInput: { flex: 1, backgroundColor: "#FFFDF8", minHeight: 48, borderRadius: 13, borderWidth: 1, borderColor: "#E3D7C6", paddingHorizontal: 12, color: "#202522", textAlign: "right", fontSize: 12 },
  measureTools: { marginTop: 10, gap: 8, padding: 12, borderRadius: 16, backgroundColor: "#F5F0E8", borderWidth: 1, borderColor: "#E3D7C6" },
  measureStatus: { color: "#817A70", fontSize: 12, lineHeight: 18, textAlign: "right" },
  measureActions: { flexDirection: "row-reverse", gap: 8 },
  measureButton: { flex: 1, borderWidth: 1, borderColor: "#CFAE8F", borderRadius: 12, paddingVertical: 9, alignItems: "center", backgroundColor: "#FFFDF8" },
  activeMeasureButton: { backgroundColor: "#EAD4C3", borderColor: "#B66A3C" },
  measureButtonText: { color: "#8A4526", fontSize: 12, fontWeight: "800" },
  measureResult: { color: "#55704B", fontSize: 13, fontWeight: "800", textAlign: "right" },
  label: { color: "#4C514C", fontSize: 14, fontWeight: "700", textAlign: "right", marginTop: 4 },
  input: { backgroundColor: "#FFFDF8", minHeight: 74, borderRadius: 15, borderWidth: 1, borderColor: "#E3D7C6", padding: 13, color: "#202522", textAlign: "right", textAlignVertical: "top", fontSize: 14 },
  analyzeButton: { minHeight: 54, borderRadius: 16, backgroundColor: "#5D6B4B", alignItems: "center", justifyContent: "center", marginTop: 2 },
  analyzeText: { color: "#FFFDF8", fontSize: 15, fontWeight: "800" },
  loadingContent: { flexDirection: "row-reverse", alignItems: "center", gap: 9 },
  disabled: { opacity: 0.7 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.98 }] },
  resultCard: { backgroundColor: "#FFFDF8", borderRadius: 22, padding: 18, borderWidth: 1, borderColor: "#E3D7C6", gap: 8 },
  resultHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  resultTitle: { flex: 1, color: "#202522", fontSize: 21, lineHeight: 28, fontWeight: "800", textAlign: "right" },
  confidencePill: { backgroundColor: "#F4E5D9", borderRadius: 12, paddingVertical: 6, paddingHorizontal: 9 },
  confidenceText: { color: "#8A4526", fontSize: 11, fontWeight: "800" },
  category: { color: "#B66A3C", fontSize: 13, fontWeight: "700", textAlign: "right" },
  resultSummary: { color: "#4C514C", fontSize: 14, lineHeight: 22, textAlign: "right" },
  resultLabel: { color: "#202522", fontSize: 14, fontWeight: "800", textAlign: "right", marginTop: 4 },
  bullet: { color: "#5D6655", fontSize: 13, lineHeight: 20, textAlign: "right" },
  interpretation: { backgroundColor: "#F7F3EA", borderRadius: 12, padding: 10, gap: 3 },
  interpretationTitle: { color: "#6D4B35", fontSize: 13, fontWeight: "800", textAlign: "right" },
  interpretationText: { color: "#5D6655", fontSize: 12, lineHeight: 18, textAlign: "right" },
  evidenceBox: { backgroundColor: "#F7F4ED", borderRadius: 16, padding: 14, gap: 5, borderWidth: 1, borderColor: "#E3D7C6" },
  comparisonRow: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 9, paddingTop: 7, borderTopWidth: 1, borderTopColor: "#E3D7C6" },
  comparisonCopy: { flex: 1, gap: 2 },
  comparisonTitle: { color: "#6D4B35", fontSize: 13, fontWeight: "800", textAlign: "right" },
  comparisonScore: { color: "#55704B", fontSize: 11, fontWeight: "800", minWidth: 78, textAlign: "left" },
  sourceText: { color: "#5D6655", fontSize: 12, lineHeight: 19, textAlign: "right" },
  limitations: { backgroundColor: "#FFF3D9", borderRadius: 16, padding: 14, gap: 5 },
  documentation: { backgroundColor: "#EEF0E8", borderRadius: 14, padding: 12, marginTop: 3 },
  documentationTitle: { color: "#46533A", fontSize: 13, fontWeight: "800", textAlign: "right" },
  documentationText: { color: "#5D6655", fontSize: 12, lineHeight: 19, textAlign: "right", marginTop: 3 },
  limitationsTitle: { color: "#805B19", fontWeight: "800", textAlign: "right", fontSize: 13 },
  limitationsText: { color: "#775E31", fontSize: 12, lineHeight: 19, textAlign: "right", marginTop: 3 },
  safeStep: { color: "#46533A", fontSize: 13, lineHeight: 20, textAlign: "right" },
  safeStepBold: { fontWeight: "800" },
  savedLabel: { color: "#5D6B4B", fontSize: 12, fontWeight: "700", textAlign: "right", marginTop: 3 },
  resultActions: { flexDirection: "row-reverse", gap: 8, marginTop: 6 },
  resultAction: { flex: 1, minHeight: 40, borderRadius: 12, borderWidth: 1, borderColor: "#D8DDCE", backgroundColor: "#F7F8F3", alignItems: "center", justifyContent: "center", paddingHorizontal: 6 },
  resultActionText: { color: "#46533A", fontSize: 11, fontWeight: "800" },
});
