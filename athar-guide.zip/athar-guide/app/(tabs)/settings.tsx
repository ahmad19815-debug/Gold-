import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useThemeContext } from "@/lib/theme-provider";
import { showUserMessage } from "@/lib/user-feedback";
import type { ColorScheme } from "@/constants/theme";

const THEME_KEY = "athar-theme-preference";
const LEGAL_KEY = "athar-legal-reminder";

export default function SettingsScreen() {
  const { colorScheme, setColorScheme } = useThemeContext();
  const [legalReminder, setLegalReminder] = useState(true);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const storedTheme = await AsyncStorage.getItem(THEME_KEY);
        const storedReminder = await AsyncStorage.getItem(LEGAL_KEY);
        if (storedTheme === "light" || storedTheme === "dark") setColorScheme(storedTheme as ColorScheme);
        if (storedReminder !== null) setLegalReminder(storedReminder !== "false");
      } catch {
        showUserMessage("تعذر تحميل الإعدادات", "ستستمر الإعدادات الافتراضية دون التأثير على التحليل.");
      }
    };
    void loadSettings();
  }, [setColorScheme]);

  const changeTheme = async (scheme: ColorScheme) => {
    setColorScheme(scheme);
    await AsyncStorage.setItem(THEME_KEY, scheme);
  };

  const toggleLegalReminder = async (value: boolean) => {
    setLegalReminder(value);
    await AsyncStorage.setItem(LEGAL_KEY, String(value));
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}><Text style={styles.kicker}>تحكم في تجربتك</Text><Text style={styles.title}>الإعدادات</Text><Text style={styles.subtitle}>إعدادات محلية بسيطة تحافظ على خصوصيتك وتوضح حدود الاستخدام.</Text></View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>المظهر</Text>
          <View style={styles.themeRow}>
            {(["light", "dark"] as ColorScheme[]).map((scheme) => (
              <Pressable key={scheme} accessibilityRole="button" accessibilityLabel={`اختيار الوضع ${scheme === "light" ? "الفاتح" : "الداكن"}`} onPress={() => void changeTheme(scheme)} style={({ pressed }) => [styles.themeOption, colorScheme === scheme && styles.themeSelected, pressed && styles.pressed]}>
                <Text style={[styles.themeText, colorScheme === scheme && styles.themeTextSelected]}>{scheme === "light" ? "فاتح" : "داكن"}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.settingRow}><View style={styles.settingCopy}><Text style={styles.settingTitle}>التذكير القانوني</Text><Text style={styles.settingText}>إظهار تنبيهات التوثيق الآمن وحدود التحليل.</Text></View><Switch accessibilityLabel="تفعيل التذكير القانوني" value={legalReminder} onValueChange={(value) => void toggleLegalReminder(value)} /></View>
        </View>

        <Pressable accessibilityRole="button" accessibilityLabel="عرض مقدمة دليل الأثر" onPress={() => router.push("/onboarding")} style={({ pressed }) => [styles.introButton, pressed && styles.pressed]}><Text style={styles.introButtonText}>عرض المقدمة من جديد</Text></Pressable>

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>التزام دليل الأثر</Text>
          <Text style={styles.noticeText}>هذا التطبيق أداة تعليمية لتحليل الصورة والسياق الثقافي. لا يستطيع إثبات وجود ذهب أو دفائن أو معادن، ولا يحدد العمق أو الاتجاه أو موقع الحفر. احترم الأنظمة المحلية واستشر جهة آثار مختصة عند الحاجة.</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 20, paddingBottom: 36, gap: 16 },
  header: { paddingBottom: 6 },
  kicker: { color: "#B66A3C", fontSize: 14, fontWeight: "800", textAlign: "right" },
  title: { color: "#202522", fontSize: 30, lineHeight: 38, fontWeight: "800", textAlign: "right", marginTop: 3 },
  subtitle: { color: "#817A70", fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 5 },
  section: { backgroundColor: "#FFFDF8", borderWidth: 1, borderColor: "#E3D7C6", borderRadius: 18, padding: 15 },
  sectionTitle: { color: "#202522", fontSize: 16, fontWeight: "800", textAlign: "right", marginBottom: 10 },
  themeRow: { flexDirection: "row-reverse", gap: 10 },
  themeOption: { flex: 1, minHeight: 45, borderRadius: 13, borderWidth: 1, borderColor: "#E3D7C6", justifyContent: "center", alignItems: "center" },
  themeSelected: { backgroundColor: "#5D6B4B", borderColor: "#5D6B4B" },
  themeText: { color: "#6D4B35", fontSize: 14, fontWeight: "800" },
  themeTextSelected: { color: "#FFFDF8" },
  settingRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 12 },
  settingCopy: { flex: 1 },
  settingTitle: { color: "#202522", fontSize: 15, fontWeight: "800", textAlign: "right" },
  settingText: { color: "#817A70", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 3 },
  introButton: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: "#B66A3C", backgroundColor: "#FFFDF8", justifyContent: "center", alignItems: "center" },
  introButtonText: { color: "#8A4526", fontSize: 14, fontWeight: "800" },
  notice: { backgroundColor: "#EEF0E8", borderWidth: 1, borderColor: "#D8DDCE", borderRadius: 18, padding: 15, gap: 6 },
  noticeTitle: { color: "#46533A", fontSize: 15, fontWeight: "800", textAlign: "right" },
  noticeText: { color: "#5D6655", fontSize: 13, lineHeight: 21, textAlign: "right" },
  pressed: { opacity: 0.75 },
});
