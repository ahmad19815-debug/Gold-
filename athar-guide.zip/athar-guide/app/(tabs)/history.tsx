import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useState } from "react";
import { FlatList, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { showUserMessage } from "@/lib/user-feedback";

const HISTORY_KEY = "athar-analysis-history";
type HistoryItem = { id: string; createdAt: string; imageUri: string; result: { title: string; category: string; summary: string; limitations?: string; nextSafeStep?: string } };

export default function HistoryScreen() {
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);

  const load = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem(HISTORY_KEY);
      setItems(stored ? JSON.parse(stored) : []);
    } catch {
      showUserMessage("تعذر تحميل السجل", "حاول إغلاق التطبيق وفتحه مرة أخرى.");
    }
  }, []);

  useFocusEffect(useCallback(() => { void load(); }, [load]));

  const clear = async () => {
    try {
      await AsyncStorage.removeItem(HISTORY_KEY);
      setItems([]);
      setSelectedItem(null);
      showUserMessage("تم مسح السجل", "أزيلت التحليلات المحفوظة من هذا الجهاز.");
    } catch {
      showUserMessage("تعذر مسح السجل", "حاول مرة أخرى.");
    }
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <View style={styles.header}><Text style={styles.kicker}>خاص بجهازك</Text><Text style={styles.title}>سجل التحليلات</Text><Text style={styles.subtitle}>تُحفظ الصور والنتائج محليًا في النسخة الأولية ولا تُزامن تلقائيًا.</Text></View>
      {items.length > 0 && <Pressable accessibilityRole="button" accessibilityLabel="مسح سجل التحليلات" onPress={() => void clear()} style={({ pressed }) => [styles.clear, pressed && styles.pressed]}><Text style={styles.clearText}>مسح السجل</Text></Pressable>}
      {selectedItem && (
        <View style={styles.detailCard}>
          <View style={styles.detailHeading}>
            <Pressable accessibilityRole="button" accessibilityLabel="إغلاق تفاصيل التحليل" onPress={() => setSelectedItem(null)} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}><Text style={styles.closeText}>إغلاق</Text></Pressable>
            <Text style={styles.detailTitle}>{selectedItem.result?.title || "تحليل صورة"}</Text>
          </View>
          <Text style={styles.category}>{selectedItem.result?.category || "قراءة ثقافية"}</Text>
          <Text style={styles.detailText}>{selectedItem.result?.summary || "لا يوجد ملخص محفوظ."}</Text>
          {selectedItem.result?.limitations && <Text style={styles.detailNote}>{selectedItem.result.limitations}</Text>}
          {selectedItem.result?.nextSafeStep && <Text style={styles.safeStep}><Text style={styles.safeStepBold}>الخطوة الآمنة التالية: </Text>{selectedItem.result.nextSafeStep}</Text>}
        </View>
      )}
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <Pressable accessibilityRole="button" accessibilityLabel={`فتح تحليل ${item.result?.title || "صورة"}`} onPress={() => setSelectedItem(item)} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
            <Image source={{ uri: item.imageUri }} style={styles.thumb} />
            <View style={styles.body}><Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString("ar-EG")}</Text><Text style={styles.cardTitle}>{item.result?.title || "تحليل صورة"}</Text><Text style={styles.category}>{item.result?.category || "قراءة ثقافية"}</Text><Text style={styles.tapHint}>اضغط لعرض النتيجة</Text></View>
          </Pressable>
        )}
        ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyIcon}>◌</Text><Text style={styles.emptyTitle}>لا توجد تحليلات بعد</Text><Text style={styles.emptyText}>ابدأ من تبويب «تحليل» لتحفظ أول قراءة تعليمية.</Text></View>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: 20, paddingBottom: 10 },
  kicker: { color: "#B66A3C", fontSize: 14, fontWeight: "800", textAlign: "right" },
  title: { color: "#202522", fontSize: 30, lineHeight: 38, fontWeight: "800", textAlign: "right", marginTop: 3 },
  subtitle: { color: "#817A70", fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 5 },
  clear: { alignSelf: "flex-end", paddingVertical: 7, paddingHorizontal: 10 },
  clearText: { color: "#A04F32", fontWeight: "800", fontSize: 13 },
  detailCard: { backgroundColor: "#EEF0E8", borderColor: "#D8DDCE", borderWidth: 1, borderRadius: 18, padding: 15, gap: 7 },
  detailHeading: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  detailTitle: { color: "#202522", fontSize: 19, lineHeight: 26, fontWeight: "800", textAlign: "right", flex: 1 },
  closeButton: { paddingVertical: 5, paddingHorizontal: 8 },
  closeText: { color: "#8A4526", fontSize: 12, fontWeight: "800" },
  detailText: { color: "#46533A", fontSize: 14, lineHeight: 21, textAlign: "right" },
  detailNote: { color: "#6C745F", fontSize: 12, lineHeight: 18, textAlign: "right" },
  safeStep: { color: "#46533A", fontSize: 12, lineHeight: 19, textAlign: "right" },
  safeStepBold: { fontWeight: "800" },
  list: { paddingTop: 4, paddingBottom: 30, gap: 10, flexGrow: 1 },
  card: { flexDirection: "row-reverse", gap: 13, backgroundColor: "#FFFDF8", borderWidth: 1, borderColor: "#E3D7C6", borderRadius: 18, padding: 11, alignItems: "center" },
  thumb: { width: 74, height: 74, borderRadius: 14, backgroundColor: "#E8E0D4" },
  body: { flex: 1, gap: 3 },
  date: { color: "#978F84", fontSize: 11, textAlign: "right" },
  cardTitle: { color: "#202522", fontSize: 16, fontWeight: "800", textAlign: "right" },
  category: { color: "#B66A3C", fontSize: 12, fontWeight: "700", textAlign: "right" },
  tapHint: { color: "#B66A3C", fontSize: 11, fontWeight: "700", textAlign: "right", marginTop: 3 },
  empty: { alignItems: "center", justifyContent: "center", flex: 1, paddingBottom: 100 },
  emptyIcon: { color: "#B66A3C", fontSize: 40 },
  emptyTitle: { color: "#202522", fontSize: 18, fontWeight: "800", marginTop: 10 },
  emptyText: { color: "#817A70", fontSize: 13, textAlign: "center", marginTop: 5 },
  pressed: { opacity: 0.7 },
});
