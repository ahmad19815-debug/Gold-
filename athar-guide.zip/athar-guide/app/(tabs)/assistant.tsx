import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import { showUserMessage } from "@/lib/user-feedback";

type Message = { id: string; role: "assistant" | "user"; text: string };

export default function AssistantScreen() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { id: "welcome", role: "assistant", text: "مرحبًا. أستطيع مساعدتك في فهم الرموز من منظور تاريخي وثقافي. اسألني عن الشكل أو السياق، وسأوضح حدود ما يمكن للصورة أن تثبته." },
  ]);
  const askMutation = trpc.analysis.ask.useMutation({
    onSuccess: (data) => setMessages((current) => [...current, { id: `${Date.now()}-a`, role: "assistant", text: data.answer }]),
    onError: (error) => showUserMessage("تعذر إرسال السؤال", error.message || "تحقق من الاتصال ثم حاول مرة أخرى."),
  });

  const send = () => {
    const text = question.trim();
    if (askMutation.isPending) return;
    if (!text) {
      showUserMessage("اكتب سؤالك أولًا", "اكتب سؤالًا عن الرمز أو سياقه التاريخي ثم اضغط إرسال.");
      return;
    }

    setMessages((current) => [...current, { id: `${Date.now()}-u`, role: "user", text }]);
    setQuestion("");
    askMutation.mutate({ question: text, context: messages.slice(-4).map((item) => `${item.role}: ${item.text}`).join("\n") });
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <View style={styles.header}><Text style={styles.kicker}>رفيق التوثيق</Text><Text style={styles.title}>المساعد الذكي</Text><Text style={styles.subtitle}>اسأل عن الرموز والتاريخ. لا يقدم المساعد قياسات عمق أو اتجاهات أو تعليمات حفر.</Text></View>
      <ScrollView style={styles.messages} contentContainerStyle={styles.messagesContent} showsVerticalScrollIndicator={false}>
        {messages.map((message) => <View key={message.id} style={[styles.bubble, message.role === "user" ? styles.userBubble : styles.assistantBubble]}><Text style={[styles.bubbleText, message.role === "user" && styles.userText]}>{message.text}</Text></View>)}
        {askMutation.isPending && <View style={styles.assistantBubble}><ActivityIndicator color="#B66A3C" /></View>}
      </ScrollView>
      <View style={styles.composer}><TextInput value={question} onChangeText={setQuestion} onSubmitEditing={send} returnKeyType="send" placeholder="اكتب سؤالك بأمان..." placeholderTextColor="#978F84" style={styles.input} multiline /><Pressable accessibilityRole="button" accessibilityLabel="إرسال السؤال" disabled={askMutation.isPending} onPress={send} style={({ pressed }) => [styles.send, pressed && styles.pressed, askMutation.isPending && styles.disabled]}>{askMutation.isPending ? <ActivityIndicator color="#FFFDF8" /> : <Text style={styles.sendText}>إرسال</Text>}</Pressable></View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: 20, paddingBottom: 10 },
  kicker: { color: "#B66A3C", fontSize: 14, fontWeight: "800", textAlign: "right" },
  title: { color: "#202522", fontSize: 30, lineHeight: 38, fontWeight: "800", textAlign: "right", marginTop: 3 },
  subtitle: { color: "#817A70", fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 5 },
  messages: { flex: 1 },
  messagesContent: { gap: 10, paddingVertical: 8 },
  bubble: { maxWidth: "88%", padding: 13, borderRadius: 17 },
  assistantBubble: { alignSelf: "flex-end", backgroundColor: "#EEF0E8", borderBottomRightRadius: 5 },
  userBubble: { alignSelf: "flex-start", backgroundColor: "#B66A3C", borderBottomLeftRadius: 5 },
  bubbleText: { color: "#46533A", fontSize: 14, lineHeight: 21, textAlign: "right" },
  userText: { color: "#FFFDF8" },
  composer: { flexDirection: "row-reverse", gap: 8, alignItems: "flex-end", paddingVertical: 10 },
  input: { flex: 1, maxHeight: 90, minHeight: 48, backgroundColor: "#FFFDF8", borderWidth: 1, borderColor: "#E3D7C6", borderRadius: 15, paddingHorizontal: 13, paddingVertical: 12, color: "#202522", textAlign: "right", fontSize: 14 },
  send: { minHeight: 48, minWidth: 70, paddingHorizontal: 16, borderRadius: 15, backgroundColor: "#5D6B4B", justifyContent: "center", alignItems: "center" },
  sendText: { color: "#FFFDF8", fontWeight: "800" },
  disabled: { opacity: 0.7 },
  pressed: { opacity: 0.75 },
});
