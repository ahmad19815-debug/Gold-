import { relations } from "drizzle-orm";

import { analyses, analysisImages, assistantConversations, assistantMessages, users } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  analyses: many(analyses),
  assistantConversations: many(assistantConversations),
}));

export const analysesRelations = relations(analyses, ({ one, many }) => ({
  user: one(users, { fields: [analyses.userId], references: [users.id] }),
  images: many(analysisImages),
}));

export const analysisImagesRelations = relations(analysisImages, ({ one }) => ({
  analysis: one(analyses, { fields: [analysisImages.analysisId], references: [analyses.id] }),
}));

export const assistantConversationsRelations = relations(assistantConversations, ({ one, many }) => ({
  user: one(users, { fields: [assistantConversations.userId], references: [users.id] }),
  messages: many(assistantMessages),
}));

export const assistantMessagesRelations = relations(assistantMessages, ({ one }) => ({
  conversation: one(assistantConversations, { fields: [assistantMessages.conversationId], references: [assistantConversations.id] }),
}));
