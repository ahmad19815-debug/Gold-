type ImageSource = {
  uri: string;
  base64?: string | null;
  mimeType?: string | null;
};

export async function toImageDataUrl(asset: ImageSource) {
  if (asset.base64) {
    return `data:${asset.mimeType || "image/jpeg"};base64,${asset.base64}`;
  }

  try {
    const response = await fetch(asset.uri);
    if (!response.ok) return null;
    const blob = await response.blob();
    return await new Promise<string | null>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(typeof reader.result === "string" ? reader.result : null);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}
