export function normalizeArabicSearch(value: string) {
  return value
    .toLocaleLowerCase()
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[إأآٱ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/ال/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

export function matchesSearch(query: string, candidates: string[]) {
  const normalizedQuery = normalizeArabicSearch(query);
  if (!normalizedQuery) return true;
  const haystack = normalizeArabicSearch(candidates.join(" "));
  return normalizedQuery.split(/\s+/).every((token) => haystack.includes(token));
}
