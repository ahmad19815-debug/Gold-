const SUPPORTED_IMAGE_TYPES = new Set(["image/jpeg", "image/jpg", "image/png", "image/webp"]);

export type ImageAssetMetadata = {
  mimeType?: string | null;
  fileSize?: number | null;
  width?: number | null;
  height?: number | null;
};

export function isAcceptableImageAsset(asset: ImageAssetMetadata) {
  const mimeType = asset.mimeType || "image/jpeg";
  if (!SUPPORTED_IMAGE_TYPES.has(mimeType)) return false;
  if (asset.fileSize && asset.fileSize > 8_000_000) return false;
  if ((asset.width && asset.width < 240) || (asset.height && asset.height < 240)) return false;
  return true;
}

export function isWithinImagePayloadLimit(dataUrls: string[], maximumCharacters = 12_000_000) {
  return dataUrls.length > 0 && dataUrls.length <= 6 && dataUrls.reduce((total, value) => total + value.length, 0) <= maximumCharacters;
}
