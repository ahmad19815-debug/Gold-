import { z } from "zod";

const boundedText = (max: number) => z.string().trim().min(1).max(max);
const evidenceLevel = z.enum(["ملاحظ بصريًا", "مقاس", "مستنتج", "موثق", "فرضية"]);
const sourceSchema = z.object({ title: boundedText(240), citation: boundedText(500), url: z.string().url().max(2048).optional(), verified: z.boolean(), reliability: z.enum(["موثوق جدًا", "موثوق", "مرجعي", "شعبي", "غير متحقق"]) }).strict();
const evidenceSchema = z.object({ level: evidenceLevel, statement: boundedText(500), basis: boundedText(500) }).strict();

export const analysisResultSchema = z.object({
  title: boundedText(160),
  category: boundedText(120),
  summary: boundedText(1200),
  observations: z.array(boundedText(400)).min(1).max(8),
  interpretations: z.array(z.object({
    label: boundedText(120),
    explanation: boundedText(600),
  }).strict()).min(1).max(4),
  why: boundedText(1200),
  confidence: z.enum(["منخفضة", "متوسطة", "مرتفعة"]),
  limitations: boundedText(1200),
  whatCannotInfer: z.array(boundedText(240)).min(1).max(8),
  documentationSteps: z.array(boundedText(300)).min(1).max(8),
  nextSafeStep: boundedText(500),
  imageQuality: boundedText(400).optional(),
  elements: z.array(z.object({ name: boundedText(120), classification: z.enum(["طبيعي محتمل", "بشري الصنع محتمل", "غير حاسم"]), description: boundedText(500) }).strict()).max(8).optional(),
  measurements: z.array(z.object({ label: boundedText(120), value: boundedText(120), basis: z.enum(["مقاس", "غير متاح", "تقديري"]) }).strict()).max(12).optional(),
  relationships: z.array(boundedText(400)).max(8).optional(),
  evidence: z.array(evidenceSchema).max(12).optional(),
  sources: z.array(sourceSchema).max(8).optional(),
}).strict();

export type AnalysisResult = z.infer<typeof analysisResultSchema>;
