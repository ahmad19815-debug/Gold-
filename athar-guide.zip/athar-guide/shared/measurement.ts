export type MeasurementPoint = { x: number; y: number };

export function distanceBetweenPoints(first: MeasurementPoint, second: MeasurementPoint) {
  return Math.hypot(second.x - first.x, second.y - first.y);
}

export function calibratedMeasurement(pixelDistance: number, referencePixels: number, referenceCentimeters: number) {
  if (!Number.isFinite(pixelDistance) || !Number.isFinite(referencePixels) || !Number.isFinite(referenceCentimeters) || referencePixels <= 0 || referenceCentimeters <= 0) {
    return null;
  }
  return (pixelDistance / referencePixels) * referenceCentimeters;
}
