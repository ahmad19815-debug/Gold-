export type EvidenceLevel = "ملاحظ بصريًا" | "مقاس" | "مستنتج" | "موثق" | "فرضية";
export type Reliability = "موثوق جدًا" | "موثوق" | "مرجعي" | "شعبي";

export type KnowledgeSource = {
  id: string;
  title: string;
  authorOrInstitution: string;
  year?: string;
  region: string;
  language: string;
  url: string;
  reliability: Reliability;
  verified: boolean;
};

export type KnowledgeEntry = {
  id: string;
  name: string;
  englishNames: string[];
  group: string;
  regions: string[];
  periods: string[];
  materials: string[];
  description: string;
  archaeologicalInterpretations: string[];
  popularInterpretations: string[];
  sourceIds: string[];
};

export const KNOWLEDGE_SOURCES: KnowledgeSource[] = [
  {
    id: "ku-arabian-rock-art",
    title: "Arabian Rock Art Heritage Project",
    authorOrInstitution: "University of Kansas Biodiversity Institute and Natural History Museum",
    year: "2010–",
    region: "السعودية وشبه الجزيرة العربية",
    language: "English",
    url: "https://biodiversity.ku.edu/archaeology/research/arabian-rock-art",
    reliability: "موثوق جدًا",
    verified: true,
  },
  {
    id: "unesco-hima",
    title: "Ḥimā Cultural Area",
    authorOrInstitution: "UNESCO World Heritage Centre",
    year: "2021",
    region: "جنوب غرب السعودية",
    language: "English",
    url: "https://whc.unesco.org/en/list/1619/",
    reliability: "موثوق جدًا",
    verified: true,
  },
  {
    id: "jubbah-landscapes",
    title: "Rock art landscapes beside the Jubbah palaeolake, Saudi Arabia",
    authorOrInstitution: "Richard P. Jennings وآخرون، Antiquity",
    year: "2013",
    region: "جبة، شمال السعودية",
    language: "English",
    url: "https://doi.org/10.1017/S0003598X00049383",
    reliability: "موثوق جدًا",
    verified: true,
  },
  {
    id: "khraysheh-safaitic-jordan",
    title: "New Safaitic inscriptions from Jordan",
    authorOrInstitution: "Fawaz H. Khraysheh، University of Yarmouk",
    year: "1995",
    region: "الأردن",
    language: "English/French",
    url: "https://www.persee.fr/doc/syria_0039-7946_1995_num_72_3_7452",
    reliability: "موثوق جدًا",
    verified: true,
  },
];

const sourceIds = ["ku-arabian-rock-art", "unesco-hima", "jubbah-landscapes"];
const safaiticSourceIds = ["khraysheh-safaitic-jordan", "unesco-hima"];

export const KNOWLEDGE_ENTRIES: KnowledgeEntry[] = [
  {
    id: "cupule",
    name: "الجرن / التجويف الدائري",
    englishNames: ["cupule", "cup mark", "rock cup", "carved cup"],
    group: "تجاويف",
    regions: ["بلاد الشام", "الأردن", "السعودية", "اليمن", "عُمان", "مصر", "المغرب العربي"],
    periods: ["غير محدد من الصورة وحدها"],
    materials: ["صخر رملي", "بازلت", "جرانيت", "غير محدد"],
    description: "تجويف مستدير أو بيضاوي في سطح صخري. قد ينتج عن تدخل بشري أو عن عوامل طبيعية، ولا يكفي التشابه الشكلي لتحديد الأصل أو الوظيفة.",
    archaeologicalInterpretations: ["قد يرتبط بسياق استعمالي أو طقسي أو تقني، ويحتاج إلى سياق موقعي ومقارنة موثقة.", "قد يكون تجويفًا طبيعيًا أو أثر تعرية."],
    popularInterpretations: ["تربطه بعض الروايات الشعبية بدفن أو اتجاه — غير مثبت أثريًا."],
    sourceIds,
  },
  {
    id: "groove",
    name: "السيال / الأخدود",
    englishNames: ["groove", "channel", "incised line"],
    group: "قنوات وأخاديد",
    regions: ["الأردن", "السعودية", "سوريا", "عُمان", "مصر", "المغرب العربي"],
    periods: ["غير محدد من الصورة وحدها"],
    materials: ["صخر رملي", "بازلت", "غير محدد"],
    description: "خط أو أخدود ممتد داخل الصخر. تُفحص استقامته وحوافه واتصاله بعناصر أخرى، لكن اتجاهه داخل الصورة ليس اتجاهًا للحفر.",
    archaeologicalInterpretations: ["قد يكون أثر أداة أو نتيجة تعرية أو استخدام وظيفي، ولا يحسم الأصل دون فحص ميداني."],
    popularInterpretations: ["تربطه بعض التفسيرات الشعبية بمسار أو هدف دفين — غير مثبت أثريًا."],
    sourceIds,
  },
  {
    id: "snake",
    name: "أفعى / ثعبان محتمل",
    englishNames: ["snake", "serpent"],
    group: "رموز حيوانية",
    regions: ["بلاد الشام", "الأردن", "السعودية", "اليمن", "مصر"],
    periods: ["غير محدد من الصورة وحدها"],
    materials: ["صخر رملي", "بازلت", "غير محدد"],
    description: "شكل متعرج قد يشبه أفعى، ويجب فحص الرأس والذيل والاستمرارية وآثار النحت والتشققات الطبيعية.",
    archaeologicalInterpretations: ["قد يكون تصويرًا رمزيًا أو زخرفيًا في سياق ثقافي معين، ولا يمكن تعميم معناه بين المناطق والحقب."],
    popularInterpretations: ["الأفعى = دفين أو اتجاه — تفسير شعبي غير مثبت أثريًا."],
    sourceIds,
  },
  {
    id: "animal-petroglyph",
    name: "حيوان منقوش محتمل",
    englishNames: ["animal petroglyph", "ibex", "camel", "horse"],
    group: "رموز حيوانية",
    regions: ["السعودية", "الأردن", "عُمان", "الإمارات", "اليمن", "المغرب العربي"],
    periods: ["فترات متعددة؛ لا تُحدد من الشكل وحده"],
    materials: ["صخر رملي", "بازلت", "غير محدد"],
    description: "تصوير حيواني محتمل يحتاج إلى مقارنة الشكل التشريحي وآثار التنفيذ والسياق البيئي والثقافي.",
    archaeologicalInterpretations: ["قد يساعد توثيق الحيوانات في دراسة البيئة والاقتصاد والتنقل، مع ضرورة ربطه بالسياق الزمني."],
    popularInterpretations: ["قد تُمنح الأشكال الحيوانية معاني كنزية في المحتوى الشعبي — غير مثبتة أثريًا."],
    sourceIds,
  },
  {
    id: "geometric",
    name: "شكل هندسي",
    englishNames: ["circle", "triangle", "cross", "star", "geometric sign"],
    group: "رموز هندسية",
    regions: ["بلاد الشام", "العراق", "الجزيرة العربية", "مصر", "المغرب العربي"],
    periods: ["غير محدد من الصورة وحدها"],
    materials: ["جميع المواد الصخرية"],
    description: "دائرة أو مثلث أو تقاطع أو شكل مركب قد يكون زخرفيًا أو طبيعيًا أو ذا وظيفة مختلفة بحسب السياق.",
    archaeologicalInterpretations: ["تُقارن الأشكال بأمثلة موثقة ضمن منطقة وفترة محددتين، ولا يُفترض ثبات المعنى عبر آلاف السنين."],
    popularInterpretations: ["ربط الشكل باتجاه أو مسافة ثابتة — غير مثبت علميًا."],
    sourceIds,
  },
  {
    id: "safaitic-inscription",
    name: "كتابة صفائية محتملة",
    englishNames: ["Safaitic inscription", "Ancient North Arabian inscription"],
    group: "كتابات ونقوش",
    regions: ["الأردن", "جنوب سوريا", "شمال السعودية"],
    periods: ["تقريبًا من القرن الأول قبل الميلاد إلى القرنين الثالث/الرابع الميلاديين؛ وفق المرجع المذكور"],
    materials: ["بازلت", "صخر صحراوي"],
    description: "تحديد نوع الكتابة من صورة غير واضحة يظل احتماليًا. القراءة الموثوقة تحتاج وضوحًا ومقارنة أشكال الحروف وسياقًا أثريًا.",
    archaeologicalInterpretations: ["قد تتوافق بعض السمات مع الكتابات الصفائية، لكن لا يجوز تحويل التشابه البصري إلى قراءة أو تأريخ مؤكد."],
    popularInterpretations: ["ترجمة النص بالتخمين أو ربطه بكنز — غير مثبت."],
    sourceIds: safaiticSourceIds,
  },
  {
    id: "natural-fracture",
    name: "تشقق أو تجويف طبيعي محتمل",
    englishNames: ["natural fracture", "weathering", "erosion pattern"],
    group: "طبيعي / غير حاسم",
    regions: ["كل المناطق"],
    periods: ["غير منطبق"],
    materials: ["صخر رملي", "بازلت", "جرانيت", "حجر جيري"],
    description: "تشققات وأنماط تعرية قد تشبه الرموز. انتظام الحواف وتكرار الشكل وحدهما لا يكفيان لإثبات تدخل بشري.",
    archaeologicalInterpretations: ["قد يفسر التجوية أو التعرية أو البنية الجيولوجية المظهر دون تدخل بشري."],
    popularInterpretations: ["اعتبار كل تجويف أو تشقق علامة مقصودة — غير مثبت علميًا."],
    sourceIds,
  },
];

export const KNOWLEDGE_GROUPS = ["الكل", ...Array.from(new Set(KNOWLEDGE_ENTRIES.map((entry) => entry.group)))];
export const KNOWLEDGE_REGIONS = ["كل المناطق", ...Array.from(new Set(KNOWLEDGE_ENTRIES.flatMap((entry) => entry.regions)))];

export const SYNONYMS: Record<string, string[]> = {
  جرن: ["جرون", "cupule", "cup mark", "rock cup"],
  سيال: ["قناة", "أخدود", "groove", "channel"],
  أفعى: ["ثعبان", "snake", "serpent"],
  نقش: ["petroglyph", "inscription", "rock art"],
};
