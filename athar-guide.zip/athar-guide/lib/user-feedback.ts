import { Alert, Platform } from "react-native";

/**
 * Uses the native alert on Android/iOS and the browser alert in web preview.
 * This keeps button failures visible instead of appearing as a no-op.
 */
export function showUserMessage(title: string, message: string) {
  if (Platform.OS === "web" && typeof globalThis.alert === "function") {
    globalThis.alert(`${title}\n\n${message}`);
    return;
  }

  Alert.alert(title, message);
}
