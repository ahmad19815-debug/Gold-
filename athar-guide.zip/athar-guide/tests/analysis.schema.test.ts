import { describe, expect, it } from "vitest";

import { analysisResultSchema } from "../shared/analysis";

const validResult = {
  title: "نقش صخري غير واضح",
  category: "غير واضح",
  summary: "تظهر خطوط متقاطعة على سطح صخري مع تفاوت في الإضاءة.",
  observations: ["خطوط متقاطعة", "سطح خشن"],
  interpretations: [
    { label: "احتمال زخرفي", explanation: "قد تكون الخطوط جزءًا من زخرفة أو أثرًا سطحيًا." },
    { label: "احتمال طبيعي", explanation: "قد تنتج الملامح عن تشقق أو تعرية طبيعية." },
  ],
  why: "الخطوط غير منتظمة ولا تظهر معها علامات كتابية مؤكدة.",
  confidence: "منخفضة" as const,
  limitations: "لا تثبت الصورة الأصل أو العمر أو الوظيفة أو وجود معدن.",
  whatCannotInfer: ["لا يمكن استنتاج وجود دفين."],
  documentationSteps: ["التصوير من زاوية أخرى مع مقياس واضح."],
  nextSafeStep: "حفظ الصورة والسياق العام واستشارة مختص عند الحاجة.",
};

describe("analysisResultSchema", () => {
  it("accepts a complete, bounded analysis result", () => {
    expect(analysisResultSchema.parse(validResult)).toEqual(validResult);
  });

  it("rejects unsafe or unknown fields", () => {
    expect(() => analysisResultSchema.parse({ ...validResult, coordinates: "1,2" })).toThrow();
  });

  it("rejects invalid confidence and empty required arrays", () => {
    expect(() => analysisResultSchema.parse({ ...validResult, confidence: "مؤكدة" })).toThrow();
    expect(() => analysisResultSchema.parse({ ...validResult, observations: [] })).toThrow();
  });
});
