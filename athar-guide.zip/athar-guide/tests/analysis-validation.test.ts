import { describe, expect, it } from "vitest";

import { parseAnalysisResponse } from "../server/analysis-validation";

const validResult = {
  title: "ملامح صخرية",
  category: "غير واضح",
  summary: "تظهر ملامح سطحية غير كافية لتحديد أصلها.",
  observations: ["سطح خشن"],
  interpretations: [{ label: "احتمال طبيعي", explanation: "قد تكون الملامح ناتجة عن التعرية." }],
  why: "لا توجد علامات كتابية أو هندسية حاسمة.",
  confidence: "منخفضة",
  limitations: "لا تثبت الصورة العمر أو الوظيفة أو وجود معدن.",
  whatCannotInfer: ["لا يمكن استنتاج وجود دفين."],
  documentationSteps: ["صوّر من زاوية أخرى مع مقياس."],
  nextSafeStep: "احفظ الصورة واستشر مختصًا عند الحاجة.",
};

describe("parseAnalysisResponse", () => {
  it("parses and validates JSON returned by the model", () => {
    expect(parseAnalysisResponse(JSON.stringify(validResult))).toEqual(validResult);
  });

  it("returns safe, user-facing errors for malformed JSON", () => {
    expect(() => parseAnalysisResponse("not-json")).toThrow("أعاد المساعد نتيجة غير صالحة");
  });

  it("rejects unexpected fields instead of passing them to the client", () => {
    expect(() => parseAnalysisResponse(JSON.stringify({ ...validResult, coordinates: "unknown" }))).toThrow("تعذر التحقق");
  });
});
