import { describe, expect, it, vi } from "vitest";

import { matchesSearch, normalizeArabicSearch } from "../shared/search";
import { toImageDataUrl } from "../shared/image-data";

describe("البحث العربي", () => {
  it("matches normalized Arabic variants and English names", () => {
    expect(normalizeArabicSearch("الإشارةُ" )).toBe("اشاره");
    expect(matchesSearch("جرن", ["الجرن", "cup-mark"])).toBe(true);
    expect(matchesSearch("cup mark", ["الجرن", "cup-mark"])).toBe(true);
    expect(matchesSearch("غير موجود", ["الجرن", "cup-mark"])).toBe(false);
  });
});

describe("تحويل الصورة", () => {
  it("uses provided base64 data immediately", async () => {
    await expect(toImageDataUrl({ uri: "file://x", base64: "abc", mimeType: "image/png" })).resolves.toBe("data:image/png;base64,abc");
  });

  it("returns null when the URI cannot be fetched", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")));
    await expect(toImageDataUrl({ uri: "file://missing" })).resolves.toBeNull();
    vi.unstubAllGlobals();
  });
});
