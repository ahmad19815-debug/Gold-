import { describe, expect, it } from "vitest";

import { calibratedMeasurement, distanceBetweenPoints } from "../shared/measurement";

describe("قياس الصور المعاير", () => {
  it("calculates pixel distance", () => {
    expect(distanceBetweenPoints({ x: 0, y: 0 }, { x: 3, y: 4 })).toBe(5);
  });

  it("converts pixels using a real reference", () => {
    expect(calibratedMeasurement(50, 100, 10)).toBe(5);
  });

  it("rejects missing or invalid calibration", () => {
    expect(calibratedMeasurement(50, 0, 10)).toBeNull();
    expect(calibratedMeasurement(50, 100, 0)).toBeNull();
    expect(calibratedMeasurement(Number.NaN, 100, 10)).toBeNull();
  });
});
