import { describe, expect, it } from "vitest";

import { isAcceptableImageAsset, isWithinImagePayloadLimit } from "../shared/image-policy";

describe("سياسة قبول الصور", () => {
  it("accepts supported, sufficiently large images", () => {
    expect(isAcceptableImageAsset({ mimeType: "image/jpeg", fileSize: 500_000, width: 1200, height: 900 })).toBe(true);
    expect(isAcceptableImageAsset({ mimeType: "image/png", width: 240, height: 240 })).toBe(true);
  });

  it("rejects unsupported, oversized, or tiny images", () => {
    expect(isAcceptableImageAsset({ mimeType: "image/gif", width: 1200, height: 900 })).toBe(false);
    expect(isAcceptableImageAsset({ mimeType: "image/jpeg", fileSize: 8_000_001, width: 1200, height: 900 })).toBe(false);
    expect(isAcceptableImageAsset({ mimeType: "image/jpeg", width: 100, height: 900 })).toBe(false);
  });

  it("limits multi-image payloads", () => {
    expect(isWithinImagePayloadLimit(["a", "b"])).toBe(true);
    expect(isWithinImagePayloadLimit([])).toBe(false);
    expect(isWithinImagePayloadLimit(new Array(7).fill("a"))).toBe(false);
    expect(isWithinImagePayloadLimit(["x".repeat(11), "y".repeat(10)], 20)).toBe(false);
  });
});
