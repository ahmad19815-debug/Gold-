import { describe, expect, it } from "vitest";

import { KNOWLEDGE_ENTRIES, KNOWLEDGE_SOURCES } from "../shared/knowledge";

describe("قاعدة معرفة دليل الأثر", () => {
  it("contains verified sources with usable metadata", () => {
    expect(KNOWLEDGE_SOURCES.length).toBeGreaterThan(0);
    for (const source of KNOWLEDGE_SOURCES) {
      expect(source.verified).toBe(true);
      expect(source.url).toMatch(/^https:\/\//);
      expect(source.title.length).toBeGreaterThan(5);
      expect(source.region.length).toBeGreaterThan(2);
    }
  });

  it("separates archaeological and popular interpretations", () => {
    expect(KNOWLEDGE_ENTRIES.length).toBeGreaterThanOrEqual(5);
    for (const entry of KNOWLEDGE_ENTRIES) {
      expect(entry.archaeologicalInterpretations.length).toBeGreaterThan(0);
      expect(entry.popularInterpretations.length).toBeGreaterThan(0);
      expect(entry.archaeologicalInterpretations.join(" ")).not.toMatch(/ذهب|دفين|حفر/);
    }
  });

  it("covers the requested categories", () => {
    const groups = new Set(KNOWLEDGE_ENTRIES.map((entry) => entry.group));
    expect(groups.has("تجاويف")).toBe(true);
    expect([...groups].some((group) => group.includes("كتابات"))).toBe(true);
    expect([...groups].some((group) => group.includes("حيوانية"))).toBe(true);
  });
});
